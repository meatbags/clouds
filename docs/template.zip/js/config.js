/** Global config. */

const Config = {
  width: 960,
  height: 540,
};

export default Config;
